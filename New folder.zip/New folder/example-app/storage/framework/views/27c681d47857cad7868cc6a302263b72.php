<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Product Table</h2>          
  <table class="table">
    <thead>
      <tr>
        <th>S.No</th>
        <th>Title</th>
        <th>Size</th>
        <th>Gender</th>
        <th>Image</th>
        <th>Options</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($item->title); ?></td>
        <td><?php echo e($item->size); ?></td>
        <td><?php echo e($item->gender); ?></td>
        <td><img class="" style="width:40px; height:40px;"
            src="<?php echo e(asset('product-images/'.$item->image)); ?>"></td>
        <td><?php $__currentLoopData = explode(',', $item->checkbox); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($option); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
        <td><a href="<?php echo e(route('product_edit',[$item->id])); ?>" class="btn btn-primary btn-sm">Edit</a>
            <a href="<?php echo e(route('product_delete',[$item->id])); ?>" class="btn btn-danger btn-sm">Delete</a>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH C:\Users\Vikash\Desktop\New folder\example-app\resources\views/show_product.blade.php ENDPATH**/ ?>